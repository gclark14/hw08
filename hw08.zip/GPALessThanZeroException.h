//
// Created by Gabe on 10/15/2017.
//

#ifndef WEEK07_GPALESSTHANZEROEXCEPTION_H
#define WEEK07_GPALESSTHANZEROEXCEPTION_H

#include <iostream>

class GPALessThanZeroException {
public:
    double gpa;
    double getGpa(){ return gpa; };
    GPALessThanZeroException(double gpa) { this->gpa = gpa; }
private:
};


#endif //WEEK07_GPALESSTHANZEROEXCEPTION_H
