//
// Created by gabriel on 8/28/17.
//

#include "BaseStudent.h"
#include "../StudentAgeLessThan9Exception.h"
#include "../GPALessThanZeroException.h"

BaseStudent::BaseStudent() {
    setName("");
    setPhoneNumber("");
    setClassStanding("");
    setId("");
    setAge(0);
    setGpa(0);
    setGender(' ');
    setDate(new Date(0,0,0));
    setGraduationDate();
}

BaseStudent::BaseStudent(std::string name, std::string phoneNumber, std::string classStanding, std::string id, int age,
                         double gpa, char gender, Date *date) {
    setName(name);
    setPhoneNumber(phoneNumber);
    setClassStanding(classStanding);
    setId(id);
    setAge(age);
    setGpa(gpa);
    setGender(gender);
    setDate(date);
    setGraduationDate();
}

void BaseStudent::setName(std::string name) {
    this->name = name;
}

void BaseStudent::setPhoneNumber(std::string phoneNumber) {
    this->phoneNumber = phoneNumber;
}

void BaseStudent::setClassStanding(std::string classStanding) {
    this->classStanding = classStanding;
}

void BaseStudent::setId(std::string id) {
    this->id = id;
}

void BaseStudent::setAge(int age) {
    this->age = age;
}

void BaseStudent::setGpa(double gpa){
    this->gpa = gpa;
}

void BaseStudent::setGender(char gender) {
    this->gender = gender;
}

void BaseStudent::setDate(Date *date) {
    this->date = date;
}

void BaseStudent::setGraduationDate() {
    // Assure that graduation date hasn't already been calculated.
    if(graduationDate.length() > 0)
        return;
    if(classStanding == "Freshman"){
        date->setYear(date->getYear()+3);
        date->setDate(date->getDay(), date->getMonth(), date->getYear());
    } else if(classStanding == "Sophomore"){
        date->setYear(date->getYear()+2);
        date->setDate(date->getDay(), date->getMonth(), date->getYear());
    } else if(classStanding == "Junior"){
        date->setYear(date->getYear()+1);
        date->setDate(date->getDay(), date->getMonth(), date->getYear());
    } else if(classStanding == "Senior") {
        date->setYear(date->getYear()+0);
        date->setDate(date->getDay(), date->getMonth(), date->getYear());
    }
    graduationDate = getDate()->getDate();
}

std::string BaseStudent::getName(){
    return name;
}

std::string BaseStudent::getPhoneNumber() {
    return phoneNumber;
}

std::string BaseStudent::getClassStanding() {
    return classStanding;
}

std::string BaseStudent::getId() {
    return id;
}

int BaseStudent::getAge(){
    return age;
}

double BaseStudent::getGpa(){
    return gpa;
}

char BaseStudent::getGender() {
    return gender;
}

void BaseStudent::printStudentToConsole(){
    printf("Name: %s\nPhone: %s\nClass Standing: %s\nID: %s\nAge: %i\nGPA: %.2f\nGender: %c\n",
           getName().c_str(), getPhoneNumber().c_str(), getClassStanding().c_str(), getId().c_str(), getAge(),
           getGpa(), getGender());
}

std::string BaseStudent::getGraduationDate() {
    return graduationDate;
}

Date* BaseStudent::getDate() {
    return date;
}

void BaseStudent::setAgeWithExceptions(int n) {
        setAge(n);
        if(getAge() < 9 && getAge() != 0) {
            throw StudentAgeLessThan9Exception(getAge());
        }
}

void BaseStudent::setGpaWithExceptions(double gpa) {
    setGpa(gpa);
    if(getGpa() < 0) {
        throw GPALessThanZeroException(getGpa());
    }
}
