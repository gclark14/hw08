//
// Created by gabriel on 8/28/17.
//

#ifndef WEEK02_STUDENT_H
#define WEEK02_STUDENT_H

#include <iostream>
#include <cstdio>
#include "../Date/Date.h"

class BaseStudent {
private:
    std::string name;
    std::string phoneNumber;
    std::string classStanding;
    std::string id;
    std::string graduationDate;
    int age;
    double gpa;
    char gender;

    Date *date;

    Date * getDate();

public:
    std::string getName();
    std::string getPhoneNumber();
    std::string getClassStanding();
    std::string getId();
    std::string getGraduationDate();
    int getAge();
    double getGpa();
    char getGender();

    void setName(std::string name);
    void setPhoneNumber(std::string phoneNumber);
    void setClassStanding(std::string classStanding);
    void setId(std::string id);
    void setAge(int age);
    void setGpa(double gpa);
    void setGender(char gender);
    void setDate(Date *date);
    void setGraduationDate();

    void setAgeWithExceptions(int n);

    virtual void printStudentToConsole();

    BaseStudent();
    BaseStudent(std::string name, std::string phoneNumber, std::string classStanding, std::string id, int age, double gpa, char gender, Date *date);

    void setGpaWithExceptions(double gpa);
};


#endif //WEEK02_STUDENT_H

