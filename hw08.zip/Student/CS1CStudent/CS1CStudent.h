//
// Created by gabriel on 8/30/17.
//

#ifndef WEEK02_CS1CSTUDENT_H
#define WEEK02_CS1CSTUDENT_H


#include "../BaseStudent.h"
#include <cstdio>

class CS1CStudent: public BaseStudent {
private:
    int assignmentScore;
    std::string pythonKnowledge;


public:
    int getAssignmentScore();
    std::string getPythonKnowledge();

    void setAssignmentScore(int assignmentScore);
    void setPythonKnowledge(std::string pythonKnowledge);

    void printStudentToConsole();

    CS1CStudent();
    CS1CStudent(int assignmentScore, std::string pythonKnowledge);
    CS1CStudent(std::string name, std::string phoneNumber, std::string classStanding, std::string id, int age,
                double gpa, char gender, Date *date);
    CS1CStudent(std::string name, std::string phoneNumber, std::string classStanding, std::string id, int age,
                double gpa, char gender, Date *date, int assignmentScore, std::string pythonKnowledge);
};


#endif //WEEK02_CS1CSTUDENT_H
