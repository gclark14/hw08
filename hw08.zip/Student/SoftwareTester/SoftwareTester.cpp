//
// Created by gabriel on 10/4/17.
//

#include "SoftwareTester.h"


char *SoftwareTester::getObjectAddress() const {
    return address;
}

void SoftwareTester::setObjectAddress(char *objectAddress) {
    SoftwareTester::address = objectAddress;
}

char *SoftwareTester::getCity() const {
    return city;
}

void SoftwareTester::setCity(char *city) {
    SoftwareTester::city = city;
}

char *SoftwareTester::getState() const {
    return state;
}

void SoftwareTester::setState(char *state) {
    SoftwareTester::state = state;
}

char *SoftwareTester::getZipCode() const {
    return zipCode;
}

void SoftwareTester::setZipCode(char *zipCode) {
    SoftwareTester::zipCode = zipCode;
}

SoftwareTester::SoftwareTester(const SoftwareTester &tester) {
    printf(("\nIn copy constructor. Object passed in as reference"));
    deepCopy(tester);
}

void SoftwareTester::deepCopy(const SoftwareTester &tester) {
    printf("\nDeep copy. Object passed in as value");
    city = tester.getCity();
    zipCode = tester.getZipCode();
    state = tester.getState();
}

SoftwareTester &SoftwareTester::returnByReference(const SoftwareTester &tester){
    printf("\nReturn by reference");
    deepCopy(tester);
    return *this;
}

SoftwareTester::~SoftwareTester() {
    printf("\nDestructor called");
    address = 0;
    state = 0;
    zipCode = 0;
}

SoftwareTester SoftwareTester::returnByCopy(SoftwareTester tester) {
    printf("\nReturning by copy. Object passed in as value");
    return SoftwareTester(tester);
}

SoftwareTester::SoftwareTester() {

}

SoftwareTester::SoftwareTester(std::string name, std::string id, std::string phoneNumber, int age, char gender,
                               std::string classStanding, double gpa) {
    setName(name);
    setId(id);
    setPhoneNumber(phoneNumber);
    setAge(age);
    setGender(gender);
    setClassStanding(classStanding);
    setGpa(gpa);

}

void SoftwareTester::printTesterWithoutAddedFields() {
    printStudentToConsole();
}

void SoftwareTester::printAddedFields() {
    printf("Name: %s\n", getName().c_str());
    printf("Address: %s\n", getObjectAddress());
    printf("City: %s\n", getCity());
    printf("Zipcode: %s\n", getZipCode());
}

bool isSameAge(BaseStudent *a, BaseStudent *b) {
    return a->getAge() == b->getAge();
}

int SoftwareTester::addToAge(int years) {
    setAge(getAge()+years);
    return years;
}

int SoftwareTester::operator+(int years) {
    setAge(getAge()+years);
    return years;
}

bool SoftwareTester::operator==(BaseStudent *a) {
    return getAge() == a->getAge();
}


