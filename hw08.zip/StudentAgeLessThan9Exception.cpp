//
// Created by Gabe on 10/15/2017.
//

#include "StudentAgeLessThan9Exception.h"
#include <cstdio>

StudentAgeLessThan9Exception::StudentAgeLessThan9Exception(int n) {
    age = n;
}
