//
// Created by Gabe on 10/15/2017.
//

#ifndef WEEK07_STUDENTAGELESSTHAN9EXCEPTION_H
#define WEEK07_STUDENTAGELESSTHAN9EXCEPTION_H

#include <iostream>
class StudentAgeLessThan9Exception {
private:
    int age;
public:
    int getAge() { return age; }
    StudentAgeLessThan9Exception(int n);
};


#endif //WEEK07_STUDENTAGELESSTHAN9EXCEPTION_H
