#include "Student/BaseStudent.h"
#include "StudentAgeLessThan9Exception.h"
#include "GPALessThanZeroException.h"
#include <cassert>

int main() {

    BaseStudent clark;
    int n = 11;

    // Case that works
    try {
        clark.setAgeWithExceptions(n);
    }
    catch(StudentAgeLessThan9Exception ex){
        printf("Age of %d, less than 9. Try again an age greater than 9.", ex.getAge());
        clark.setAgeWithExceptions(10);
    }
    assert(clark.getAge() > 9);

    // Case that does not work
    try {
        clark.setAgeWithExceptions(n-3);
    }
    catch(StudentAgeLessThan9Exception ex){
        printf("Age of %d, less than 9. Try again an age greater than 9.", ex.getAge());
        clark.setAgeWithExceptions(10);
    }
    // Force the value down as execution would be stuck in a loop at the try catch block
    clark.setAge(4);
    // Assertion will fail
    assert(clark.getAge() > 9);

    printf("\n\n\n");

    try{
        clark.setGpaWithExceptions(-1);
    }
    catch (GPALessThanZeroException ex){
        printf("GPA of %.2f, less than 0. Try again with a gpa greater than 0.", ex.getGpa());
        clark.setGpa(10);
    }
    clark.setGpa(0);
    assert(clark.getGpa() > 0);

    try{
        clark.setGpaWithExceptions(n);
    }
    catch (GPALessThanZeroException ex){
        printf("GPA of %.2f, less than 0. Try again with a gpa greater than 0.", ex.getGpa());
        clark.setGpa(10);
    }
    assert(clark.getGpa() > 0);

    return 0;
}

